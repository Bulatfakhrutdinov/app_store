import sqlite3
import string
import sys
from datetime import datetime, timedelta
from functools import partial

import xlsxwriter
from PyQt5 import Qt
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QDialog, QLCDNumber, QLineEdit

from ui.export_dialog import Ui_Dialog
from ui.reg_window import UIRegWindow
from ui.yandex_project import Ui_MainWindow

DB_NAME = 'db/stopwatch_data.db'
TICK_TIME = 2 ** 6
RUS_ALPH = [
    'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н',
    'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь',
    'э', 'ю', 'я']


class AuthWindow(Qt.QMainWindow, UIRegWindow):
    """
    Окно регистрации/авторизации пользователя
    """
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.password.setEchoMode(QLineEdit.Password)
        self.sign_in_btn.clicked.connect(self.sign_in)
        self.sign_up_btn.clicked.connect(self.sign_up)

    def sign_in(self):
        """
        Логика авторизации в программу
        """
        login = f'{self.login.text()}'
        password = f'{self.password.text()}'
        connection = sqlite3.connect(DB_NAME)
        cursor = connection.cursor()
        result = cursor.execute("""SELECT * FROM users WHERE login = ?
         and password = ?""", (login, password)).fetchall()
        if len(result) == 0:
            self.error_label.setText('Неверный логин или пароль!')
        else:
            watch = StopWatch(login)
            watch.show()

    def sign_up(self):
        """
        Логика регистрации
        """
        log = f'{self.login.text()}'
        pas = f'{self.password.text()}'
        count = 1
        login_correct = True
        bool_value = False
        for s in log:
            if s in string.punctuation:
                login_correct = False
                self.error_label.setText(
                    'Логин не должен содержать спец.символы!'
                )
                break

        if login_correct:
            while count != 0:
                if len(log) > 0:
                    if len(log) >= 4:
                        if len(pas) > 0:
                            if len(pas) >= 8:
                                if 'qwerty' in pas:
                                    self.error_label.setText('Слабый пароль!')
                                    count = 0
                                elif '1234' in pas:
                                    self.error_label.setText('Слабый пароль!')
                                    count = 0
                                elif pas.isdigit():
                                    self.error_label.setText(
                                        'В пароле дожны быть буквы!'
                                    )
                                    count = 0
                                elif pas.isalpha():
                                    self.error_label.setText(
                                        'В пароле должны быть цифры!'
                                    )
                                    count = 0
                                elif log == pas:
                                    self.error_label.setText(
                                        'Логин не должен совпадать с паролем!'
                                    )
                                    count = 0
                                elif pas.islower():
                                    self.error_label.setText(
                                        'В пароле должны быть заглавные буквы!'
                                    )
                                    count = 0
                                elif pas.isupper():
                                    self.error_label.setText(
                                        'В пароле должны быть строчные буквы!'
                                    )
                                    count = 0
                                else:
                                    rus_letter = 0
                                    for i in pas:
                                        if i.lower() in RUS_ALPH:
                                            rus_letter = 1

                                    if rus_letter == 1:
                                        self.error_label.setText(
                                            'В пароле не должны быть русские буквы!'
                                        )
                                        count = 0
                                    else:
                                        bool_value = True
                                        count = 0
                            else:
                                self.error_label.setText('Коротий пароль!')
                                count = 0
                        else:
                            self.error_label.setText(
                                'Пароль не должен быть пустым!'
                            )
                            count = 0
                    else:
                        self.error_label.setText('Короткий логин!')
                        count = 0
                else:
                    self.error_label.setText('Логин не должен быть пустым!')
                    count = 0
        if bool_value:
            con = sqlite3.connect(DB_NAME)
            cur = con.cursor()
            log_check = cur.execute(
                """SELECT * FROM users WHERE login = ?""", (log,)).fetchall()
            pas_check = cur.execute(
                """SELECT * FROM users WHERE password = ?""", (pas,)).fetchall()
            if len(log_check) > 0:
                self.error_label.setText('Такой логин уже существует!')
            elif len(pas_check) > 0:
                self.error_label.setText('Такой пароль уже существует!')
            else:
                cur.execute('''INSERT INTO users VALUES (?, ?)''', (log, pas))
                con.commit()
                con.close()
                self.close()
                watch = StopWatch(log)
                watch.show()


class ExportDialogWindow(QDialog, Ui_Dialog):
    """
    Окно выгрузки значений
    """

    def __init__(self, time_values, login):
        super().__init__()
        self.time_values = time_values
        self.login = login
        self.setupUi(self)
        self.sorting = 0
        self.radioButton_1.sorting = 1
        self.radioButton_1.toggled.connect(self.process_sorting)
        self.radioButton_2.sorting = 2
        self.radioButton_2.toggled.connect(self.process_sorting)
        self.checkBox_1.stateChanged.connect(
            partial(self.export_xls, self.checkBox_1)
        )
        self.checkBox_2.stateChanged.connect(
            partial(self.export_sql, self.checkBox_2)
        )
        self.pushButton.clicked.connect(self.process_export)
        self.export_type = ['txt']

    def process_sorting(self):
        """
        Флаг сортировки
        """
        rb = self.sender()
        self.sorting = rb.sorting

    def export_xls(self, checkBox_1):
        """
        Флаг выгрузки в xls
        """
        if checkBox_1.isChecked():
            self.export_type.append('xls')
        else:
            self.export_type.remove('xls')

    def export_sql(self, checkBox_2):
        """
        Флаг выгрузки в базу данных
        """
        if checkBox_2.isChecked():
            self.export_type.append('sql')
        else:
            self.export_type.remove('sql')

    def process_export(self):
        """
        Выгрузка данных
        """
        line_text = self.lineEdit.text()
        if line_text == '':
            line_text = self.login
        filename_correct = True
        for s in line_text:
            if s in string.punctuation:
                filename_correct = False
                break
        if not filename_correct:
            self.label_3.setText('Ошибка в имени файла!')
            return

        if self.sorting == 1:
            self.time_values.sort()
        if self.sorting == 2:
            self.time_values.sort(key=lambda x: x[1], reverse=True)

        if 'txt' in self.export_type:
            with open(
                    f'export/{line_text}.txt', encoding='utf-8', mode='w'
            ) as file:
                for time in self.time_values:
                    file.write(f'{time[0]} - {time[1]} \n')
                    self.close()
        if 'xls' in self.export_type:
            workbook = xlsxwriter.Workbook(f'export/{line_text}.xlsx')
            worksheet = workbook.add_worksheet()
            worksheet.set_column(0, 0, 23)
            for row, (item, price) in enumerate(self.time_values):
                worksheet.write(row, 0, item)
                worksheet.write(row, 1, price)
            workbook.close()
            self.close()
        if 'sql' in self.export_type:
            con = sqlite3.connect(f'export/db_{self.login}.db')
            cur = con.cursor()
            create_table = '''
            CREATE TABLE if not exists stopwatch_values (
                "field_name" text,
                "value"	real,
                "export_time" text
            );
            '''
            cur.execute(create_table)
            cur.executemany(
                """INSERT INTO stopwatch_values (
                "field_name", "value", "export_time") 
                VALUES (?, ?, datetime("now"));""",
                self.time_values
            )
            con.commit()
            con.close()
            self.close()


class StopWatch(Qt.QMainWindow, Ui_MainWindow):
    """
    Основное окно с секундомерами
    """

    def __init__(self, login):
        super().__init__()
        self.login = login
        self.lcdNumber = QLCDNumber(self)
        self.lcdNumber.move(180, 35)
        self.lcdNumber.setStyleSheet("border: 1px solid blue;")
        self.num_timers = 15
        self.load_window()
        self.time_run()

    def load_window(self, old_time_all=None):
        if not old_time_all:
            old_time_all = []
        self.setupUi(self)
        self.updateButton.clicked.connect(self.update_timers)
        self.startAll.clicked.connect(self.do_start_all)
        self.resetAll.clicked.connect(self.do_reset_all)
        self.unloadButton.clicked.connect(self.export)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.time_run)
        self.timer.start(1000)

        i = 1
        while True:
            try:
                timer = getattr(self, f'timer_{i}')
                try:
                    timer.timeout.disconnect()
                except TypeError:
                    pass
                i += 1
            except AttributeError:
                break

        self.lcdNumber.setNumDigits(8)
        for i in range(1, self.num_timers + 1):
            reset_btn = getattr(self, f'resetButton_{i}')
            reset_btn.clicked.connect(partial(self.do_reset, i))
            start_btn = getattr(self, f'startButton_{i}')
            start_btn.clicked.connect(partial(self.do_start, start_btn, i))
            setattr(self, f'timer_{i}', Qt.QTimer())
            timer = getattr(self, f'timer_{i}')
            timer.setInterval(TICK_TIME)
            timer.timeout.connect(partial(self.tick, i))

        if old_time_all:
            self.do_reset_saved(old_time_all)
        else:
            self.do_reset_all()

    def update_timers(self):
        """
        Изменение количества секундомеров на окне
        """
        old_time_all = self.time_all[:]
        self.old_values = []
        for i in range(1, self.num_timers + 1):
            line = getattr(self, f'lineEdit_{i}')
            self.old_values.append(line.text())
        self.num_timers = self.spinBox.value()
        self.load_window(old_time_all)

    def time_run(self):
        """
        Изменение текущего времени
        """
        self.begin = datetime.strptime(
            str(datetime.now().strftime('%Y-%m-%d %H:%M:%S').split()[1]),
            '%H:%M:%S'
        )
        if self.begin == datetime.strptime(str('00:00:00'), '%H:%M:%S'):
            self.timer.stop()
            return
        self.begin = self.begin + timedelta(seconds=1)
        self.lcdNumber.display(str(self.begin).split()[1])

    def keyPressEvent(self, event):
        """
        Закрытие окна при нажатии на клавишу Esc
        """
        if event.key() == Qt.Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)

    def display_all(self):
        """
        Вывод значений секундомеров на все дисплеи
        """
        for i in range(1, self.num_timers + 1):
            lcd = getattr(self, f'timeLcd_{i}')
            lcd.display("%d:%05.2f" % (
                self.time_all[i - 1] // 60, self.time_all[i - 1] % 60
            ))

    @Qt.pyqtSlot()
    def tick_all(self):
        """
        Изменение значений секундомеров
        """
        for i in range(0, self.num_timers):
            self.time_all[i] += TICK_TIME / 1000
        self.display_all()

    def do_start_all(self):
        """
        Запуск всех секундомеров
        """
        for i in range(1, self.num_timers + 1):
            btn = getattr(self, f'startButton_{i}')
            btn.setText('Пауза')
            btn.clicked.disconnect()
            btn.clicked.connect(partial(self.do_pause, btn, i))
            timer = getattr(self, f'timer_{i}')
            timer.start()
        self.startAll.setText("Пауза")
        self.startAll.clicked.disconnect()
        self.startAll.clicked.connect(self.do_pause_all)

    def do_pause_all(self):
        """
        Пауза на всех секундомерах
        """
        btn_text = True
        for i in range(1, self.num_timers + 1):
            btn = getattr(self, f'startButton_{i}')
            if self.time_all[i - 1] != 0:
                btn.setText('Продолж.')
                btn_text = False
            else:
                btn.setText('Старт')
            btn.clicked.disconnect()
            btn.clicked.connect(partial(self.do_start, btn, i))
            timer = getattr(self, f'timer_{i}')
            timer.stop()
        if btn_text == True:
            self.startAll.setText('Старт')
        else:
            self.startAll.setText('Продолжить')
        self.startAll.clicked.disconnect()
        self.startAll.clicked.connect(self.do_start_all)

    def do_reset_all(self):
        """
        Обнуление всех секундомеров
        """
        self.time_all = [0 for i in range(1, self.num_timers + 1)]
        self.display_all()
        for i in range(1, self.num_timers + 1):
            timer = getattr(self, f'timer_{i}')
            timer.stop()
            btn = getattr(self, f'startButton_{i}')
            btn.setText('Старт')
            btn.clicked.disconnect()
            btn.clicked.connect(partial(self.do_start, btn, i))

        self.startAll.setText('Старт')
        self.startAll.clicked.disconnect()
        self.startAll.clicked.connect(self.do_start_all)

    def do_reset_saved(self, old_time_all):
        """
        Изменение количества секундомеров в списке
        :param old_time_all: список старых значений секундомеров
        """
        self.time_all = [0 for i in range(1, self.num_timers + 1)]
        self.value = []
        for i in range(1, self.num_timers + 1):
            line = getattr(self, f'lineEdit_{i}')
            self.value.append(line.text())
        for i in range(min(self.num_timers, len(old_time_all))):
            self.time_all[i] = old_time_all[i]
            self.value[i] = self.old_values[i]
        self.display_all()
        for i in range(1, self.num_timers + 1):
            line = getattr(self, f'lineEdit_{i}')
            line.setText(self.value[i - 1])
            if self.time_all[i - 1] > 0:
                btn = getattr(self, f'startButton_{i}')
                btn.setText('Продолж.')
        self.startAll.setText('Старт')
        self.startAll.clicked.disconnect()
        self.startAll.clicked.connect(self.do_start_all)

    def tick(self, ind):
        """
        Изменения значения одного секундомера
        :param ind: индекс секундомера в списке
        """
        self.time_all[ind - 1] += TICK_TIME / 1000
        self.display(ind)

    def display(self, ind):
        """
        Отрисовка значения секундомера на дисплее
        :param ind: индекс секундомера в списке
        """
        lcd = getattr(self, f'timeLcd_{ind}')
        lcd.display("%d:%05.2f" % (
            self.time_all[ind - 1] // 60, self.time_all[ind - 1] % 60
        ))

    @Qt.pyqtSlot()
    def do_start(self, btn, ind):
        """
        Запуск секундомера
        :param btn: название кнопки
        :param ind: индекс секундомера в списке
        """
        timer = getattr(self, f'timer_{ind}')
        timer.start()
        btn.setText("Пауза")
        btn.clicked.disconnect()
        btn.clicked.connect(partial(self.do_pause, btn, ind))

    @Qt.pyqtSlot()
    def do_pause(self, btn, ind):
        """
        Пауза секундомера
        :param btn: название кнопки
        :param ind: индекс секундомера в списке
        """
        timer = getattr(self, f'timer_{ind}')
        timer.stop()
        btn.setText("Продолж.")
        btn.clicked.disconnect()
        btn.clicked.connect(partial(self.do_start, btn, ind))

    @Qt.pyqtSlot()
    def do_reset(self, ind):
        """
        Сброс значения на секундомере
        :param ind: индекс секундомера в списке
        """
        self.time_all[ind - 1] = 0
        self.display(ind)
        timer = getattr(self, f'timer_{ind}')
        timer.stop()
        btn = getattr(self, f'startButton_{ind}')
        btn.setText('Старт')

    def export(self):
        """
        Открывает окно выгрузки значений
        """
        self.do_pause_all()
        values = []
        for i in range(1, self.num_timers + 1):
            field_name = getattr(self, f'lineEdit_{i}')
            if self.time_all[i - 1] != 0:
                values.append(
                    (field_name.text(), round(self.time_all[i - 1], 3)))
        dlg = ExportDialogWindow(values, self.login)
        dlg.exec_()


app = Qt.QApplication(sys.argv)
watch = AuthWindow()
watch.show()
app.exec_()
