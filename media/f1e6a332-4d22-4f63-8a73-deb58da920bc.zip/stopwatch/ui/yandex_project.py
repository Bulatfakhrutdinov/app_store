from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        """
        Создание окна с виджетами
        """
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(788, 630)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(30, 30, 141, 30))
        font = QtGui.QFont()
        font.setFamily("Segoe UI Black")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.startAll = QtWidgets.QPushButton(self.centralwidget)
        self.startAll.setGeometry(QtCore.QRect(460, 30, 141, 23))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.startAll.setFont(font)
        self.startAll.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.startAll.setObjectName("startAll")
        self.resetAll = QtWidgets.QPushButton(self.centralwidget)
        self.resetAll.setGeometry(QtCore.QRect(620, 30, 141, 23))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.resetAll.setFont(font)
        self.resetAll.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.resetAll.setObjectName("resetAll")
        self.unloadButton = QtWidgets.QPushButton(self.centralwidget)
        self.unloadButton.setGeometry(QtCore.QRect(631, 559, 131, 23))
        self.unloadButton.setObjectName("unloadButton")
        self.scrollArea = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea.setGeometry(QtCore.QRect(30, 80, 731, 470))
        self.scrollArea.setWidgetResizable(False)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QtWidgets.QWidget()

        magic_heigth = (
            (self.num_Rs // 3 + 1) * 3
            if self.num_timers % 3 != 0 else self.num_timers)
        self.scrollAreaWidgetContents.setGeometry(
            QtCore.QRect(0, 0, 699, 31 * magic_heigth)
        )
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.gridLayout = QtWidgets.QGridLayout(self.scrollAreaWidgetContents)
        self.gridLayout.setObjectName("gridLayout")

        x_cord = 0
        y_cord = 0
        _translate = QtCore.QCoreApplication.translate
        for i in range(1, self.num_timers + 1):
            setattr(
                self, f'widget{i}',
                QtWidgets.QWidget(self.scrollAreaWidgetContents)
            )
            widget = getattr(self, f'widget{i}')
            widget.setObjectName(f"widget_{i}")

            setattr(self, f'timeLcd_{i}', QtWidgets.QLCDNumber(widget))
            timeLcd = getattr(self, f'timeLcd_{i}')
            timeLcd.setGeometry(QtCore.QRect(20, 20, 123, 23))
            timeLcd.setStyleSheet("border-color: rgb(0, 0, 0);")
            timeLcd.setDigitCount(10)
            timeLcd.setObjectName(f"timeLcd_{i}")


            setattr(self, f'lineEdit_{i}', QtWidgets.QLineEdit(widget))
            lineEdit = getattr(self, f'lineEdit_{i}')
            lineEdit.setGeometry(QtCore.QRect(20, 50, 123, 20))
            lineEdit.setObjectName(f"lineEdit_{i}")

            setattr(self, f'resetButton_{i}', QtWidgets.QPushButton(widget))
            resetButton = getattr(self, f'resetButton_{i}')
            resetButton.setGeometry(QtCore.QRect(150, 50, 61, 23))
            resetButton.setObjectName(f"resetButton_{i}")

            setattr(self, f'startButton_{i}', QtWidgets.QPushButton(widget))
            startButton = getattr(self, f'startButton_{i}')
            startButton.setGeometry(QtCore.QRect(150, 20, 61, 23))
            startButton.setStyleSheet("background-color: rgb(255, 255, 255);")
            startButton.setObjectName(f"startButton_{i}")
            self.gridLayout.addWidget(widget, y_cord, x_cord, 1, 1)

            x_cord += 1
            if i % 3 == 0:
                x_cord = 0
                y_cord += 1

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.spinBox = QtWidgets.QSpinBox(self.centralwidget)
        self.spinBox.setGeometry(QtCore.QRect(30, 560, 41, 22))
        self.spinBox.setProperty("value", self.num_timers)
        self.spinBox.setObjectName("spinBox")
        self.updateButton = QtWidgets.QPushButton(self.centralwidget)
        self.updateButton.setGeometry(QtCore.QRect(80, 559, 75, 24))
        self.updateButton.setObjectName("updateButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 788, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Stopwatch"))
        self.label.setText(_translate("MainWindow", "Текущее время:"))
        self.startAll.setText(_translate("MainWindow", "Старт"))
        self.resetAll.setText(_translate("MainWindow", "Сброс"))
        self.unloadButton.setText(_translate("MainWindow", "Выгрузить"))
        self.updateButton.setText(_translate("MainWindow", "Обновить"))

        for i in range(1, self.num_timers + 1):
            lineEdit = getattr(self, f'lineEdit_{i}')
            lineEdit.setText(_translate(
                "MainWindow", f"Название поля {i}..."
            ))
            getattr(self, f'resetButton_{i}').setText(
                _translate("MainWindow", "Сброс")
            )
            getattr(self, f'startButton_{i}').setText(
                _translate("MainWindow", "Старт")
            )
